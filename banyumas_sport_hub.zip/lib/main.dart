import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'pages/user/user_main_page.dart';

void main() {
  runApp(const BanyumasSportHubApp());
}

class BanyumasSportHubApp extends StatelessWidget {
  const BanyumasSportHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Banyumas SportHub',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const UserMainPage(),
    );
  }
}