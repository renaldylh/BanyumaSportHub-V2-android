import 'package:flutter/material.dart';
import '../admin/admin_main_page.dart'; // arahkan ke dashboard admin

class LoginAdminPage extends StatelessWidget {
  const LoginAdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Login Admin"),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const SizedBox(height: 40),
            const Icon(Icons.admin_panel_settings, size: 100, color: Colors.blue),
            const SizedBox(height: 20),
            const Text("Masuk sebagai Admin",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: "Email Admin"),
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: "Kata Sandi"),
              obscureText: true,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: const Size.fromHeight(45),
              ),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const AdminMainPage()),
                );
              },
              child: const Text("Masuk"),
            ),
          ],
        ),
      ),
    );
  }
}
