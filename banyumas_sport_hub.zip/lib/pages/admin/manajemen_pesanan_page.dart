// lib/pages/admin/manajemen_pesanan_page.dart
import 'package:flutter/material.dart';
import 'detail_pesanan_page.dart';

class ManajemenPesananPage extends StatelessWidget {
  const ManajemenPesananPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: 6,
      separatorBuilder: (_,__) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        return Card(
          child: ListTile(
            leading: const Icon(Icons.receipt_long, color: Colors.blue),
            title: Text('Order #00${i+1} • Rp ...'),
            subtitle: Text('Nama Pelanggan • 10 Nov 2025'),
            trailing: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailPesananPage())), style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), child: const Text('Detail')),
          ),
        );
      },
    );
  }
}
