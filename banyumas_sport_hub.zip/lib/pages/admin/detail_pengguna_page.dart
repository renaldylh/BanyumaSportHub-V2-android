import 'package:flutter/material.dart';

class DetailPenggunaPage extends StatelessWidget {
  const DetailPenggunaPage({super.key});

  @override
  Widget build(BuildContext context) {
    final pesanan = [
      {'id': '#001', 'total': 'Rp 350.000', 'status': 'Selesai'},
      {'id': '#002', 'total': 'Rp 120.000', 'status': 'Dikirim'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Pengguna'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text('Profil Pengguna', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            const Text('Nama: Budi Santoso'),
            const Text('Email: budi@gmail.com'),
            const Text('Telepon: 08123456789'),
            const Text('Peran: User'),
            const Text('Bergabung: 1 Jan 2024'),
            const Divider(height: 32),
            const Text('Riwayat Pesanan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ...pesanan.map((p) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.receipt, color: Colors.blue),
                    title: Text('Order ${p['id']}'),
                    subtitle: Text('${p['status']}'),
                    trailing: Text(p['total']!),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
