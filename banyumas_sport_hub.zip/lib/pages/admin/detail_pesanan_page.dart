// lib/pages/admin/detail_pesanan_page.dart
import 'package:flutter/material.dart';

class DetailPesananPage extends StatelessWidget {
  const DetailPesananPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detail Pesanan'), backgroundColor: Colors.blue),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Order #001', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Nama Pelanggan: Nama Contoh'),
          const Text('Tanggal: 10 Nov 2025'),
          const SizedBox(height: 12),
          const Text('Item Pesanan', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              children: const [
                ListTile(title: Text('Produk A'), subtitle: Text('Qty: 2 • Rp 100.000'), trailing: Text('Rp 200.000')),
                ListTile(title: Text('Produk B'), subtitle: Text('Qty: 1 • Rp 75.000'), trailing: Text('Rp 75.000')),
              ],
            ),
          ),
          const Divider(),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
            Text('Total Pembelian', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Rp 275.000', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Status diperbarui (UI)'))), style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), child: const Text('Ubah Status')),
        ]),
      ),
    );
  }
}
