// lib/pages/admin/manajemen_pengguna_page.dart
import 'package:flutter/material.dart';
import 'detail_pengguna_page.dart';

class ManajemenPenggunaPage extends StatelessWidget {
  const ManajemenPenggunaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: 6,
      separatorBuilder: (_,__) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        return Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person, color: Colors.white), backgroundColor: Colors.blue),
            title: Text('Nama Pengguna ${i+1}'),
            subtitle: const Text('email@example.com'),
            trailing: ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DetailPenggunaPage())), style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), child: const Text('Lihat')),
          ),
        );
      },
    );
  }
}
