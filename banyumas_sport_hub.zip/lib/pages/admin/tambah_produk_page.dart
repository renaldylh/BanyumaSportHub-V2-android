import 'package:flutter/material.dart';

class TambahProdukPage extends StatelessWidget {
  const TambahProdukPage({super.key});

  @override
  Widget build(BuildContext context) {
    final namaCtl = TextEditingController();
    final hargaCtl = TextEditingController();
    final stokCtl = TextEditingController();
    final deskripsiCtl = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Produk Baru'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(controller: namaCtl, decoration: const InputDecoration(labelText: 'Nama Produk')),
            TextField(controller: deskripsiCtl, decoration: const InputDecoration(labelText: 'Deskripsi Produk')),
            TextField(controller: hargaCtl, decoration: const InputDecoration(labelText: 'Harga (Rp)'), keyboardType: TextInputType.number),
            TextField(controller: stokCtl, decoration: const InputDecoration(labelText: 'Stok'), keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Tambah Produk'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Produk baru ditambahkan (UI)')),
                );
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
