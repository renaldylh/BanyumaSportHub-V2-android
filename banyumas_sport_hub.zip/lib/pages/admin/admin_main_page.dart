import 'package:flutter/material.dart';
import '../../app_theme.dart';
import 'dashboard_admin_page.dart';
import 'manajemen_produk_page.dart';
import 'manajemen_pesanan_page.dart';
import 'manajemen_pengguna_page.dart';

class AdminMainPage extends StatefulWidget {
  const AdminMainPage({super.key});

  @override
  State<AdminMainPage> createState() => _AdminMainPageState();
}

class _AdminMainPageState extends State<AdminMainPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    DashboardAdminPage(),
    ManajemenProdukPage(),
    ManajemenPesananPage(),
    ManajemenPenggunaPage(),
  ];

  final List<String> _titles = const [
    "Dashboard",
    "Produk",
    "Pesanan",
    "Pengguna",
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.secondaryColor,
      appBar: AppBar(
        backgroundColor: AppTheme.primaryColor,
        elevation: 0,
        title: Text(
          _titles[_selectedIndex],
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
        ),
        centerTitle: true,
      ),
      drawer: _buildDrawer(context),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: AppTheme.primaryColor,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard), label: "Dashboard"),
          BottomNavigationBarItem(icon: Icon(Icons.store), label: "Produk"),
          BottomNavigationBarItem(
              icon: Icon(Icons.receipt_long), label: "Pesanan"),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: "Pengguna"),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: Column(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: AppTheme.primaryColor,
              borderRadius:
                  const BorderRadius.only(bottomRight: Radius.circular(40)),
            ),
            child: const Align(
              alignment: Alignment.bottomLeft,
              child: Text(
                "Banyumas SportHub Admin",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          _drawerItem(Icons.dashboard, "Dashboard", 0),
          _drawerItem(Icons.store, "Manajemen Produk", 1),
          _drawerItem(Icons.receipt_long, "Manajemen Pesanan", 2),
          _drawerItem(Icons.people, "Manajemen Pengguna", 3),
          const Spacer(),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: const Text(
              "Logout",
              style: TextStyle(color: Colors.redAccent),
            ),
            onTap: () {
              Navigator.pushReplacementNamed(context, '/login_admin');
            },
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, int index) {
    final bool selected = _selectedIndex == index;
    return ListTile(
      leading: Icon(icon,
          color: selected ? AppTheme.primaryColor : Colors.grey.shade700),
      title: Text(
        label,
        style: TextStyle(
          color: selected ? AppTheme.primaryColor : Colors.black87,
          fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
        ),
      ),
      selected: selected,
      onTap: () {
        Navigator.pop(context);
        setState(() {
          _selectedIndex = index;
        });
      },
    );
  }
}
