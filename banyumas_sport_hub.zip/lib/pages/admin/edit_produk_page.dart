// lib/pages/admin/edit_produk_page.dart
import 'package:flutter/material.dart';

class EditProdukPage extends StatelessWidget {
  const EditProdukPage({super.key});

  @override
  Widget build(BuildContext context) {
    final namaCtl = TextEditingController(text: 'Nama Produk contoh');
    final desCtl = TextEditingController(text: 'Deskripsi contoh');
    final hargaCtl = TextEditingController(text: '100000');
    final stokCtl = TextEditingController(text: '10');

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Produk'), backgroundColor: Colors.blue),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: namaCtl, decoration: const InputDecoration(labelText: 'Nama Produk')),
          const SizedBox(height: 8),
          TextField(controller: desCtl, decoration: const InputDecoration(labelText: 'Deskripsi')),
          const SizedBox(height: 8),
          TextField(controller: hargaCtl, decoration: const InputDecoration(labelText: 'Harga (Rp)'), keyboardType: TextInputType.number),
          const SizedBox(height: 8),
          TextField(controller: stokCtl, decoration: const InputDecoration(labelText: 'Stok'), keyboardType: TextInputType.number),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Perubahan disimpan (UI)'))); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.blue), child: const Text('Update Produk')),
        ]),
      ),
    );
  }
}
