// lib/pages/admin/dashboard_admin_page.dart
import 'package:flutter/material.dart';

class DashboardAdminPage extends StatelessWidget {
  const DashboardAdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        children: [
          _kartuStat('Total Pengguna', '230'),
          _kartuStat('Total Pendapatan', 'Rp 1.650.000'),
          _kartuStat('Total Pesanan', '89'),
          _kartuStat('Total Produk', '48'),
        ],
      ),
    );
  }

  Widget _kartuStat(String title, String value) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blue)),
          const SizedBox(height: 6),
          Text(title),
        ]),
      ),
    );
  }
}
