// lib/pages/admin/manajemen_produk_page.dart
import 'package:flutter/material.dart';
import 'tambah_produk_page.dart';
import 'edit_produk_page.dart';

class ManajemenProdukPage extends StatelessWidget {
  const ManajemenProdukPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(children: [
            const Text('Manajemen Produk', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TambahProdukPage())),
              icon: const Icon(Icons.add),
              label: const Text('Tambah Produk'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            )
          ]),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.separated(
              itemCount: 6,
              separatorBuilder: (_,__) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.shopping_bag, color: Colors.white), backgroundColor: Colors.blue),
                    title: Text('Produk ${i+1}'),
                    subtitle: const Text('Rp ... • Stok: ... • Dibuat: 10 Nov 2025'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProdukPage())), icon: const Icon(Icons.edit, color: Colors.orange)),
                      IconButton(onPressed: () => _confirmHapus(context), icon: const Icon(Icons.delete, color: Colors.red)),
                    ]),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }

  void _confirmHapus(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Hapus Produk'),
        content: const Text('Apakah Anda yakin ingin menghapus produk ini?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Produk dihapus (UI)'))); }, child: const Text('Hapus'))
        ],
      ),
    );
  }
}
