import 'package:flutter/material.dart';
import '../../../app_theme.dart';

class MarketplacePage extends StatelessWidget {
  const MarketplacePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.secondaryColor,
      appBar: AppBar(
        title: const Text("Marketplace Olahraga"),
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // 🔍 Search bar
            TextField(
              decoration: InputDecoration(
                hintText: "Cari perlengkapan olahraga...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // 🏷️ Kategori
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  _buildCategoryChip("Semua", true),
                  _buildCategoryChip("Sepak Bola", false),
                  _buildCategoryChip("Badminton", false),
                  _buildCategoryChip("Basket", false),
                  _buildCategoryChip("Gym", false),
                  _buildCategoryChip("Renang", false),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 🏪 Daftar Produk
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.75,
                children: [
                  _buildProductCard(
                    context,
                    "Sepatu Futsal Nike ZoomX",
                    "Rp 899.000",
                    "assets/images/shoes.png",
                  ),
                  _buildProductCard(
                    context,
                    "Raket Badminton Yonex",
                    "Rp 450.000",
                    "assets/images/racket.png",
                  ),
                  _buildProductCard(
                    context,
                    "Bola Basket Molten",
                    "Rp 350.000",
                    "assets/images/basketball.png",
                  ),
                  _buildProductCard(
                    context,
                    "Matras Yoga Biru",
                    "Rp 150.000",
                    "assets/images/yoga_mat.png",
                  ),
                  _buildProductCard(
                    context,
                    "Kacamata Renang Speedo",
                    "Rp 120.000",
                    "assets/images/swim_goggles.png",
                  ),
                  _buildProductCard(
                    context,
                    "Sarung Tangan Gym ProGrip",
                    "Rp 99.000",
                    "assets/images/gym_gloves.png",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🎯 Widget untuk chip kategori
  Widget _buildCategoryChip(String label, bool selected) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        selectedColor: AppTheme.primaryColor,
        backgroundColor: Colors.white,
        labelStyle: TextStyle(
          color: selected ? Colors.white : AppTheme.primaryColor,
          fontWeight: FontWeight.w500,
        ),
        onSelected: (_) {},
      ),
    );
  }

  // 🛒 Widget untuk card produk
  Widget _buildProductCard(BuildContext context, String title, String price, String imagePath) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 3,
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () {
          _showProductDetail(context, title, price, imagePath);
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar produk
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              child: Image.asset(
                imagePath,
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(price,
                      style: TextStyle(
                          color: AppTheme.primaryColor,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  Center(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryColor,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () {},
                      icon: const Icon(Icons.add_shopping_cart, size: 16),
                      label: const Text("Tambah"),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔍 Detail produk (popup)
  void _showProductDetail(BuildContext context, String title, String price, String imagePath) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.asset(imagePath, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(title,
                      style:
                          const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(price,
                      style: TextStyle(
                          color: AppTheme.primaryColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  const Text(
                    "Produk olahraga berkualitas tinggi untuk menunjang aktivitas dan gaya hidup sehat Anda.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 15),
                  ElevatedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    icon: const Icon(Icons.shopping_bag_outlined),
                    label: const Text("Tambah ke Keranjang"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
