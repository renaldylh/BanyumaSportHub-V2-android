import 'package:flutter/material.dart';
import '../../../app_theme.dart';

class KeranjangPage extends StatelessWidget {
  const KeranjangPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> cartItems = [
      {
        "title": "Sepatu Futsal Nike ZoomX",
        "price": 899000,
        "image": "assets/images/shoes.png",
        "quantity": 1,
      },
      {
        "title": "Raket Badminton Yonex",
        "price": 450000,
        "image": "assets/images/racket.png",
        "quantity": 2,
      },
    ];

    double totalHarga = cartItems.fold(
        0, (sum, item) => sum + (item["price"] * item["quantity"]));

    return Scaffold(
      backgroundColor: AppTheme.secondaryColor,
      appBar: AppBar(
        title: const Text("Keranjang Saya"),
        centerTitle: true,
        elevation: 0,
      ),
      body: cartItems.isEmpty
          ? const Center(
              child: Text(
                "Keranjang masih kosong 😢",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      final item = cartItems[index];
                      return _buildCartItem(context, item);
                    },
                  ),
                ),

                // 🧾 Total dan tombol checkout
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black12,
                          blurRadius: 5,
                          offset: const Offset(0, -2))
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Total",
                              style: TextStyle(color: Colors.grey)),
                          Text(
                            "Rp ${totalHarga.toStringAsFixed(0)}",
                            style: TextStyle(
                                color: AppTheme.primaryColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 18),
                          ),
                        ],
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryColor,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 30, vertical: 12),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () {
                          _showCheckoutDialog(context);
                        },
                        icon: const Icon(Icons.payment_rounded),
                        label: const Text("Checkout"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  // 🧺 Widget item keranjang
  Widget _buildCartItem(BuildContext context, Map<String, dynamic> item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 3,
      child: ListTile(
        contentPadding: const EdgeInsets.all(10),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.asset(
            item["image"],
            width: 60,
            height: 60,
            fit: BoxFit.cover,
          ),
        ),
        title: Text(item["title"],
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
          "Rp ${item["price"]} x ${item["quantity"]}",
          style: TextStyle(color: AppTheme.primaryColor),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
          onPressed: () {
            _showDeleteConfirmation(context, item["title"]);
          },
        ),
      ),
    );
  }

  // 🗑️ Konfirmasi hapus item
  void _showDeleteConfirmation(BuildContext context, String title) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Text("Hapus Item"),
        content: Text("Apakah kamu yakin ingin menghapus \"$title\" dari keranjang?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
            ),
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Item dihapus dari keranjang")),
              );
            },
            child: const Text("Hapus"),
          ),
        ],
      ),
    );
  }

  // 💳 Dialog checkout
  void _showCheckoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.check_circle_outline,
                  color: AppTheme.primaryColor, size: 60),
              const SizedBox(height: 10),
              const Text(
                "Checkout Berhasil!",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                "Pesananmu sedang diproses. Terima kasih telah berbelanja di Banyumas SportHub!",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text("Oke, Mengerti"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
