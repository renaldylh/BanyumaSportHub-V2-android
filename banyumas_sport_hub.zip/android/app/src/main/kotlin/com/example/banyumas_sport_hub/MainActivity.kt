package com.example.banyumas_sport_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
